package com.example.rehomemobileapp.network.request;


public class StatusUpdateRequest {
    private String status;

    public StatusUpdateRequest(String status) {
        this.status = status;
    }
}

